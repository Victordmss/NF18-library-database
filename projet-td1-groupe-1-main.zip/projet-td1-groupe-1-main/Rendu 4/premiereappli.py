import psycopg2
HOST = "tuxa.sme.utc"
USER = "nf18a002"
PASSWORD = "a0wvXvKA"
DATABASE = "dbnf18a002"

def main():
    
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cur = conn.cursor()

    nom_saisi = input("Saisissez un acteur dont vous souhaitez connaître les films dans lesquels il a joué (Harrison Ford par exemple): ")
    
    sql1 = f"""SELECT R.code, R.titre, R.date_apparition FROM Ressource R
    JOIN Film F ON R.code = F.code 
    JOIN Film_acteur FA ON F.code = FA.code_film 
    JOIN Contributeur C ON FA.id_contributeur = C.id_contributeur
    WHERE C.nom = {nom_saisi}"""

    cur.execute(sql1)
    res = cur.fetchall()

    print(f"Films dans lesquels {nom_saisi} a joué: ")
    for ligne in res:
        print(f"Code: {ligne[0]} ; Titre: {ligne[1]} ; Date d’apparition: {ligne[2]}")

    
            #Ajout ressource
    print("Vous allez ajouter une ressource.")
    titre_saisi = input("Entrez le titre : ")
    date_saisi = input("Entrez la date d’apparition (format YYYY-MM-DD) : ")
    editeur_saisi = input("Entrez l’éditeur : ")
    code_class_saisi = input("Entrez le code de classification de la ressource : ")
    prix_saisi = float(input("Entrez le prix de la ressource : "))

    sql2 = "INSERT INTO Ressource VALUES (DEFAULT,%s,%s,%s,%s,%s);"
    data = (titre_saisi, date_saisi, editeur_saisi, code_class_saisi, prix_saisi)
    cur.execute(sql2, data)
    #conn.commit()

    type_saisi = input("Entrez le type de la ressource (livre, film ou musique) : ")
    if type_saisi == "film":
        nom_realisateur_saisi = input("Entrez le nom du réalisateur : ")
        sqla = f"SELECT id_contributeur FROM Contributeur WHERE Contributeur.nom = '{nom_realisateur_saisi}';"
        cur.execute(sqla)
        retour = cur.fetchall()
        rowCount = len(retour)
        if rowCount == 0:  # il faut créer le réalisateur
            print("Le réalisateur n'existe pas. Il sera ajouté : \n")
            date_naiss_saisi = input("entrer la date (format YYYY-MM-DD) : ")
            nationalite_saisi = input("entrer la nationalité : ")
            sqlaa = f"INSERT INTO Contributeur VALUES (DEFAULT, '{nom_realisateur_saisi}', '{date_naiss_saisi}', '{nationalite_saisi}');"
            cur.execute(sqlaa)
            sqlab = f"SELECT id_contributeur FROM Contributeur WHERE nom = '{nom_realisateur_saisi}' AND date_naiss = '{date_naiss_saisi}' AND nationalite = '{nationalite_saisi}';"
            cur.execute(sqlab)
            id_realisateur = int(cur.fetchone()[0])
        else:
            id_realisateur = int(retour[0][0])
        # récupération du code ressource
        sqlb = "SELECT code FROM Ressource WHERE titre = %s AND date_apparition = %s AND editeur = %s AND code_classification = %s AND prix = %s;"
        data = (titre_saisi, date_saisi, editeur_saisi, code_class_saisi, prix_saisi)
        cur.execute(sqlb, data)
        code_saisi = int(cur.fetchone()[0])
        synopsis_saisi = input("Entrez le synopsis :")
        langue_saisi = input("Entrez la langue : ")
        duree_saisi = int(input("Entrez la durée (minutes) : "))
        sqlc = "INSERT INTO film (code,synopsis,langue,duree,realisateur) VALUES (%s, %s, %s, %s, %s);"
        data = (code_saisi, synopsis_saisi, langue_saisi, duree_saisi, id_realisateur)
        cur.execute(sqlc, data)


    
    #Classement des emprunts afin de trouver les ressources les plus empruntées
    
    sql3 = """SELECT pret.code_ressource, R.titre,COUNT(pret.code_ressource) AS nb_total_pret FROM pret 
    JOIN Ressource R ON pret.code_ressource = R.code
    GROUP BY pret.code_ressource, R.titre
    ORDER BY nb_total_pret DESC;"""
    
    cur.execute(sql3)
    res = cur.fetchall()

    print("Affichage des ressources dans l’ordre des plus empruntés aux moins empruntés")
    for ligne in res:
        print(f"Code: {ligne[0]} ; Titre: {ligne[1]} ; Nombre de prêt: {ligne[2]}")




    cur.commit()

    conn.close()
